// =============================================================
//  FIREBASE CONFIG  —  i-paste dito ang config ng Firebase project mo
//  Firebase Console > Project settings > General > Your apps > Web app
//
//  Habang hindi pa napapalitan ang "PASTE_..." values, gagana ang app
//  sa LOCAL MODE (localStorage) — pang-test sa iisang browser lang.
// =============================================================
window.FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
